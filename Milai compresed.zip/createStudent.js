import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  "https://dtumdjzpugggsbtmhlsr.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR0dW1kanpwdWdnZ3NidG1obHNyIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjM3MDA2OCwiZXhwIjoyMDcxOTQ2MDY4fQ.8l5-Ej_Kk8zcK5YumI6VY4qPhnSUJq5xrKtb-XE9z-I"  // not anon, use service role
);

async function createStudent() {
  const registration = "REG1001";
  const pin = "1234";

  const email = `${registration}@school.local`;

  const { data, error } = await supabase.auth.admin.createUser({
    email,
    password: pin,
    email_confirm: true,
    user_metadata: {
      registration,
      role: "student",
    },
  });

  if (error) {
    console.error("❌ Failed to create user:", error.message);
  } else {
    console.log("✅ Student created:", data.user);
  }
}

createStudent();
