// testSupabase.js
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  "https://dtumdjzpugggsbtmhlsr.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR0dW1kanpwdWdnZ3NidG1obHNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYzNzAwNjgsImV4cCI6MjA3MTk0NjA2OH0.eccSmytNnAdA6OxxWKufItVnNpVo77j6qa4ZSJkU6Bg"
);

async function testConnection() {
  const { data, error } = await supabase.from("profiles").select("id").limit(1);

  if (error) {
    console.error("❌ Connection failed:", error.message);
  } else {
    console.log("✅ Connected! Sample data:", data);
  }
}

testConnection();
